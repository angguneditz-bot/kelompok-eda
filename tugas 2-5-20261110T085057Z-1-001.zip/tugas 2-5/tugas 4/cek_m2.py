#!/usr/bin/env python3
"""
cek_m2.py — Pemeriksa kelengkapan kiriman M2 (Data Quality Report)
Exploratory Data Analysis (KMTI21133) — Pertemuan 5

Cara pakai, dari dalam folder repositori tim:
    python cek_m2.py

Skrip ini memeriksa KELENGKAPAN, bukan kualitas isi. Lolos semua pemeriksaan
tidak berarti nilai M2 Anda penuh; nilai tetap ditentukan Rubrik M2.
Yang dijamin skrip ini: berkas Anda tidak hilang, tidak salah tempat, dan
tidak memuat data pribadi yang seharusnya tidak diunggah.
"""
import json, os, re, sys

HIJAU, MERAH, KUNING, ABU, TEBAL, RESET = (
    '\033[92m', '\033[91m', '\033[93m', '\033[90m', '\033[1m', '\033[0m')
if os.name == 'nt' and not os.environ.get('WT_SESSION'):
    HIJAU = MERAH = KUNING = ABU = TEBAL = RESET = ''

lulus, gagal, ingat = [], [], []
def ok(p):    lulus.append(p); print(f'  {HIJAU}LULUS{RESET}  {p}')
def no(p, s): gagal.append(p); print(f'  {MERAH}GAGAL{RESET}  {p}\n         {ABU}-> {s}{RESET}')
def wr(p, s): ingat.append(p); print(f'  {KUNING}INGAT{RESET}  {p}\n         {ABU}-> {s}{RESET}')
def judul(t): print(f'\n{TEBAL}{t}{RESET}')

def ada(path):
    return os.path.exists(path)

def cari(*kandidat):
    for k in kandidat:
        if ada(k):
            return k
    return None

print(f'{TEBAL}Pemeriksa kelengkapan M2 — Data Quality Report{RESET}')
print(f'{ABU}Folder diperiksa: {os.path.abspath(".")}{RESET}')

# ---------- 1. struktur folder ----------
judul('1. Struktur repositori')
for d in ['data/raw', 'data/processed', 'notebooks', 'reports']:
    if os.path.isdir(d):
        ok(f'Folder {d}/ ada')
    else:
        no(f'Folder {d}/ ada', f'Buat dengan: mkdir -p {d}')

# ---------- 2. berkas wajib ----------
judul('2. Berkas wajib M2')
laporan = cari('reports/data_quality_report.docx', 'reports/data_quality_report.pdf',
               'reports/data_quality_report.md')
if laporan:
    ok(f'Laporan ditemukan: {laporan}')
else:
    no('Laporan Data Quality Report', 'Simpan di reports/data_quality_report.docx')

nb = None
if os.path.isdir('notebooks'):
    kand = [f for f in os.listdir('notebooks')
            if f.endswith('.ipynb') and re.search(r'clean|bersih|02', f, re.I)]
    nb = os.path.join('notebooks', kand[0]) if kand else None
if nb:
    ok(f'Notebook pembersihan ditemukan: {nb}')
else:
    no('Notebook pembersihan', 'Simpan sebagai notebooks/02_cleaning.ipynb')

log = cari('cleaning_log.md', 'reports/cleaning_log.md', 'docs/cleaning_log.md')
if log:
    ok(f'Cleaning log ditemukan: {log}')
else:
    no('cleaning_log.md', 'Simpan di akar repositori dengan nama cleaning_log.md')

if ada('README.md'):
    ok('README.md ada')
else:
    no('README.md', 'README wajib memuat provenans data dari pertemuan 3')

# ---------- 3. isi cleaning log ----------
judul('3. Isi cleaning log')
if log:
    teks = open(log, encoding='utf-8', errors='ignore').read()
    baris_tabel = [b for b in teks.splitlines()
                   if b.strip().startswith('|') and b.count('|') >= 3
                   and not re.match(r'^\s*\|[\s\-:|]+\|\s*$', b)]
    isi = [b for b in baris_tabel if not re.search(r'langkah|step|alasan|reason', b, re.I)]
    if len(isi) >= 5:
        ok(f'Cleaning log memuat {len(isi)} langkah')
    elif len(isi) > 0:
        wr(f'Cleaning log memuat {len(isi)} langkah',
           'Dataset yang sudah diperiksa pada pertemuan 4 biasanya menghasilkan minimal 5 langkah')
    else:
        no('Cleaning log memuat langkah dalam bentuk tabel',
           'Pakai kolom: # | Langkah | Baris terdampak | Alasan')

    kata_alasan = ['karena', 'sebab', 'agar', 'alasan', 'dipilih', 'ditolak', 'dipertimbangkan']
    if any(k in teks.lower() for k in kata_alasan):
        ok('Cleaning log memuat kata penjelas alasan')
    else:
        no('Cleaning log memuat alasan, bukan hanya tindakan',
           'Rubrik M2 memberi bobot 30 untuk justifikasi. Tulis MENGAPA, bukan hanya APA.')

    if re.search(r'ditolak|alternatif|dipertimbangkan|sebaliknya', teks, re.I):
        ok('Ada alternatif yang dipertimbangkan dan ditolak')
    else:
        wr('Minimal satu alternatif yang ditolak disebutkan',
           'Rubrik tingkat 4 mensyaratkan alternatif dipertimbangkan')
else:
    no('Isi cleaning log', 'Berkasnya belum ada')

# ---------- 4. notebook dapat dijalankan ----------
judul('4. Notebook pembersihan')
if nb:
    try:
        doc = json.load(open(nb, encoding='utf-8'))
        sel = doc.get('cells', [])
        kode = [c for c in sel if c.get('cell_type') == 'code']
        teks_kode = '\n'.join(''.join(c.get('source', [])) for c in kode)

        ok(f'Notebook terbaca: {len(sel)} sel, {len(kode)} sel kode')

        if 'data/raw' in teks_kode:
            ok('Notebook membaca dari data/raw/')
        else:
            wr('Notebook membaca dari data/raw/', 'Pastikan sumbernya data mentah, bukan berkas yang sudah diolah')

        if 'data/processed' in teks_kode or 'to_csv' in teks_kode:
            ok('Notebook menyimpan hasil')
        else:
            no('Notebook menyimpan hasil ke data/processed/', 'Tambahkan to_csv() di akhir pipeline')

        if re.search(r'\bdef\s+\w*(bersih|clean|prepar)', teks_kode, re.I):
            ok('Pembersihan dibungkus dalam fungsi')
        else:
            wr('Pembersihan dibungkus dalam fungsi',
               'Pipeline berupa fungsi lebih mudah dijalankan ulang pada pertemuan 15')

        kosong = sum(1 for c in kode if not ''.join(c.get('source', [])).strip())
        if kosong > 3:
            wr(f'Ada {kosong} sel kode kosong', 'Hapus sel percobaan sebelum mengumpulkan')
        else:
            ok('Tidak ada sel kode kosong berlebihan')

        belum = sum(1 for c in kode if c.get('execution_count') is None
                    and ''.join(c.get('source', [])).strip())
        if belum == 0:
            ok('Seluruh sel kode sudah pernah dijalankan')
        else:
            wr(f'{belum} sel kode belum pernah dijalankan',
               'Jalankan Restart and run all, lalu simpan ulang')
    except Exception as e:
        no('Notebook dapat dibaca', f'{type(e).__name__}: {e}')
else:
    no('Notebook pembersihan', 'Berkasnya belum ada')

# ---------- 5. data pribadi ----------
judul('5. Keamanan data (lanjutan pertemuan 3)')
if ada('.gitignore'):
    gi = open('.gitignore', encoding='utf-8', errors='ignore').read()
    if re.search(r'data/raw', gi):
        ok('data/raw/ terdaftar di .gitignore')
    else:
        no('data/raw/ terdaftar di .gitignore', 'Tambahkan baris: data/raw/')
else:
    no('.gitignore ada', 'Buat .gitignore dan masukkan data/raw/ ke dalamnya')

POLA = {
    'NIK 16 digit'    : r'\b\d{16}\b',
    'nomor telepon'   : r'\b08\d{8,12}\b',
    'alamat surel'    : r'\b[\w.\-]+@[\w\-]+\.[a-z]{2,}\b',
}
ABAIKAN = {'.git', 'data', '.ipynb_checkpoints', '__pycache__', 'node_modules', '.venv'}
temuan = []
for akar, subdir, berkas in os.walk('.'):
    subdir[:] = [s for s in subdir if s not in ABAIKAN and not s.startswith('.')]
    for b in berkas:
        if not b.endswith(('.ipynb', '.md', '.csv', '.py', '.txt')):
            continue
        p = os.path.join(akar, b)
        try:
            isi = open(p, encoding='utf-8', errors='ignore').read()
        except Exception:
            continue
        for nama, pola in POLA.items():
            n = len(re.findall(pola, isi))
            if n:
                temuan.append((p, nama, n))
if temuan:
    for p, nama, n in temuan[:8]:
        no(f'{p} memuat {nama} ({n} kemunculan)',
           'Periksa apakah ini data pribadi sungguhan. Bersihkan keluaran sel lalu commit ulang.')
    if len(temuan) > 8:
        print(f'         {ABU}... dan {len(temuan) - 8} temuan lain{RESET}')
else:
    ok('Tidak ditemukan pola NIK, nomor telepon, atau surel di berkas yang diunggah')

# ---------- 6. data mentah tidak berubah ----------
judul('6. Data mentah')
if os.path.isdir('data/raw'):
    isi_raw = [f for f in os.listdir('data/raw') if not f.startswith('.')]
    if isi_raw:
        ok(f'data/raw/ berisi {len(isi_raw)} berkas sumber')
    else:
        wr('data/raw/ kosong', 'Data mentah tetap disimpan secara lokal meskipun tidak diunggah')
if os.path.isdir('data/processed'):
    isi_pro = [f for f in os.listdir('data/processed') if not f.startswith('.')]
    if isi_pro:
        ok(f'data/processed/ berisi {len(isi_pro)} berkas hasil')
    else:
        no('data/processed/ berisi hasil pembersihan', 'Simpan hasil pipeline Anda di sini')

# ---------- ringkasan ----------
print(f'\n{TEBAL}{"=" * 62}{RESET}')
print(f'  {HIJAU}LULUS{RESET} {len(lulus)}    {MERAH}GAGAL{RESET} {len(gagal)}    {KUNING}INGAT{RESET} {len(ingat)}')
print(f'{TEBAL}{"=" * 62}{RESET}')
if gagal:
    print(f'\n{MERAH}Perbaiki yang berstatus GAGAL sebelum mengumpulkan:{RESET}')
    for p in gagal:
        print(f'  - {p}')
if ingat:
    print(f'\n{KUNING}Tidak menggugurkan, tetapi memengaruhi nilai rubrik:{RESET}')
    for p in ingat:
        print(f'  - {p}')
if not gagal:
    print(f'\n{HIJAU}Kelengkapan terpenuhi.{RESET} Nilai akhir M2 tetap ditentukan Rubrik M2:')
    print('  kelengkapan diagnosis (25) - justifikasi (30) - ketepatan implementasi (20)')
    print('  - dokumentasi dan keterlacakan (15) - penanganan data pribadi (10)')
print()
sys.exit(1 if gagal else 0)
